_**Instruction Template**_

**THIS IS AN EXAMPLE TEMPLATE**

**Make sure the following boxes are checked out(and the vars replaced) *BEFORE* you're submitting this issue**

**Screenshots are more than welcome!**

**Please remove any unused content (including these instructions) before submitting your issue.**

**Thanks :smile:**

**Checklist:**

- [ ] I'm sure this issue is not a *duplicate*?
- [ ] I want to create an icon request(if not, remove these lines below):
      - Type: [extension/folder]
      - Icon Name: [name]
      - Sample original Icon(32x32/svg/transparent whenever possible): [url]
      - Extensions: .just, .a, .bunch, .of, .extensions

