***Fixes #[ISSUE]***

**Changes proposed:**
* [ ] Add
* [ ] Prepare
* [ ] Delete
* [ ] Fix

**Things I've done:**
* [ ] I've pulled the latest master branch.
* [ ] I've run `npm install` to install all the dependencies.
* [ ] I've run ESLint.
* [ ] My pull request fixes an issue, I referenced the issue.
* [ ] I've run `npm run build` to build the extension.

[short comment]
